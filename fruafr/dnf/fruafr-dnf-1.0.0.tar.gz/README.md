# Ansible Collection - fruafr.dnf

Ansible collection providing a wrapper around ansible.builtin.dnf for common dnf activities.

The target is Red Hat - based systems.

Support by distribution and major version (intentions):

| **Distribution** | **7** | **8** | **9** |
|---|---|---|---|
| **Red Hat Enterprise Linux (RHEL)** | Y (no EPEL next release) | Y | Y |
| Oracle Linux (OL) | Y (no EPEL next release) | Y | Y |
| Rocky Linux | N | Y | Y |
| Almalinux | N | Y | Y |
| CentOS Stream [RHEL upstream] | N | Y | Y |
| CentOS [RHEL Downstream] | Y (no EPEL next release) | ? | N |
| Fedora [RHEL Devel] | ? (v19+) | ? (v28+) | v38+ (v34+) |

License
-------
GNU 3.0 or later


Author Information
------------------
David Heurtevent <david@heurtevent.org>